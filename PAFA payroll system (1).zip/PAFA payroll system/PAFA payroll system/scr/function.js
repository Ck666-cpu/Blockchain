let web3;
		let payrollDAppContract;
		const contractAddress = "0xf1750BE97e0186384884344a5EBc0B082c20110D";
		const contractABI =[
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "_employee",
						"type": "address"
					},
					{
						"internalType": "bool",
						"name": "_isPartTime",
						"type": "bool"
					},
					{
						"internalType": "uint256",
						"name": "_hourlyRate",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_workingHours",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_otRate",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_otHours",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_bonus",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_deduction",
						"type": "uint256"
					}
				],
				"name": "addEmployee",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "_employee",
						"type": "address"
					}
				],
				"name": "deleteEmployee",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "uint256",
						"name": "_txid",
						"type": "uint256"
					}
				],
				"name": "deleteTimelock",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"inputs": [],
				"stateMutability": "nonpayable",
				"type": "constructor"
			},
			{
				"anonymous": false,
				"inputs": [
					{
						"indexed": true,
						"internalType": "address",
						"name": "employer",
						"type": "address"
					},
					{
						"indexed": true,
						"internalType": "address",
						"name": "employee",
						"type": "address"
					}
				],
				"name": "EmployeeAdded",
				"type": "event"
			},
			{
				"anonymous": false,
				"inputs": [
					{
						"indexed": true,
						"internalType": "address",
						"name": "employer",
						"type": "address"
					},
					{
						"indexed": false,
						"internalType": "uint256",
						"name": "amount",
						"type": "uint256"
					}
				],
				"name": "EmployerFunded",
				"type": "event"
			},
			{
				"inputs": [],
				"name": "fundEmployer",
				"outputs": [],
				"stateMutability": "payable",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "_employee",
						"type": "address"
					},
					{
						"internalType": "bool",
						"name": "_isPartTime",
						"type": "bool"
					},
					{
						"internalType": "uint256",
						"name": "_hourlyRate",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_workingHours",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_otRate",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_otHours",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_bonus",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_deduction",
						"type": "uint256"
					}
				],
				"name": "modifyEmployeeDetails",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "uint256",
						"name": "_txid",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_amount",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "_releaseTime",
						"type": "uint256"
					}
				],
				"name": "modifyTimelock",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"inputs": [],
				"name": "payAllSalaries",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "uint256",
						"name": "_txid",
						"type": "uint256"
					}
				],
				"name": "payIndividualSalary",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"inputs": [],
				"name": "registerEmployer",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"anonymous": false,
				"inputs": [
					{
						"indexed": true,
						"internalType": "address",
						"name": "employer",
						"type": "address"
					},
					{
						"indexed": true,
						"internalType": "address",
						"name": "employee",
						"type": "address"
					},
					{
						"indexed": false,
						"internalType": "uint256",
						"name": "amount",
						"type": "uint256"
					}
				],
				"name": "SalaryPaid",
				"type": "event"
			},
			{
				"anonymous": false,
				"inputs": [
					{
						"indexed": false,
						"internalType": "uint256",
						"name": "txid",
						"type": "uint256"
					}
				],
				"name": "SalaryTimelockDeleted",
				"type": "event"
			},
			{
				"anonymous": false,
				"inputs": [
					{
						"indexed": true,
						"internalType": "address",
						"name": "employer",
						"type": "address"
					},
					{
						"indexed": true,
						"internalType": "address",
						"name": "employee",
						"type": "address"
					},
					{
						"indexed": false,
						"internalType": "uint256",
						"name": "txid",
						"type": "uint256"
					},
					{
						"indexed": false,
						"internalType": "uint256",
						"name": "salary",
						"type": "uint256"
					},
					{
						"indexed": false,
						"internalType": "uint256",
						"name": "releaseTime",
						"type": "uint256"
					}
				],
				"name": "SalaryTimelockModified",
				"type": "event"
			},
			{
				"anonymous": false,
				"inputs": [
					{
						"indexed": true,
						"internalType": "address",
						"name": "employer",
						"type": "address"
					},
					{
						"indexed": true,
						"internalType": "address",
						"name": "employee",
						"type": "address"
					},
					{
						"indexed": false,
						"internalType": "uint256",
						"name": "releaseTime",
						"type": "uint256"
					},
					{
						"indexed": false,
						"internalType": "uint256",
						"name": "txid",
						"type": "uint256"
					}
				],
				"name": "SalaryTimelockSet",
				"type": "event"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "_employee",
						"type": "address"
					},
					{
						"internalType": "uint256",
						"name": "_releaseTime",
						"type": "uint256"
					}
				],
				"name": "setSalaryTimelock",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "uint256",
						"name": "_releaseTime",
						"type": "uint256"
					}
				],
				"name": "setSalaryTimelockForAll",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "uint256",
						"name": "amount",
						"type": "uint256"
					}
				],
				"name": "withdrawFunds",
				"outputs": [],
				"stateMutability": "nonpayable",
				"type": "function"
			},
			{
				"stateMutability": "payable",
				"type": "receive"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "_employer",
						"type": "address"
					},
					{
						"internalType": "address",
						"name": "_employee",
						"type": "address"
					}
				],
				"name": "calculateSalary",
				"outputs": [
					{
						"internalType": "uint256",
						"name": "",
						"type": "uint256"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "_employer",
						"type": "address"
					}
				],
				"name": "checkEmployeeList",
				"outputs": [
					{
						"internalType": "address[]",
						"name": "",
						"type": "address[]"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [],
				"name": "checkSalaryTimelocks",
				"outputs": [
					{
						"components": [
							{
								"internalType": "uint256",
								"name": "txid",
								"type": "uint256"
							},
							{
								"internalType": "address",
								"name": "employee",
								"type": "address"
							},
							{
								"internalType": "uint256",
								"name": "amount",
								"type": "uint256"
							},
							{
								"internalType": "uint256",
								"name": "releaseTime",
								"type": "uint256"
							},
							{
								"internalType": "enum PayrollDApp.TimelockStatus",
								"name": "status",
								"type": "uint8"
							},
							{
								"internalType": "bool",
								"name": "processed",
								"type": "bool"
							},
							{
								"internalType": "string",
								"name": "description",
								"type": "string"
							}
						],
						"internalType": "struct PayrollDApp.SalaryTransaction[]",
						"name": "",
						"type": "tuple[]"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					}
				],
				"name": "employerBalances",
				"outputs": [
					{
						"internalType": "uint256",
						"name": "",
						"type": "uint256"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					},
					{
						"internalType": "uint256",
						"name": "",
						"type": "uint256"
					}
				],
				"name": "employerEmployeeList",
				"outputs": [
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					},
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					}
				],
				"name": "employerEmployees",
				"outputs": [
					{
						"internalType": "bool",
						"name": "isPartTime",
						"type": "bool"
					},
					{
						"internalType": "uint256",
						"name": "hourlyRate",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "workingHours",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "otRate",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "otHours",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "bonus",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "deduction",
						"type": "uint256"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					}
				],
				"name": "employers",
				"outputs": [
					{
						"internalType": "bool",
						"name": "",
						"type": "bool"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					},
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					}
				],
				"name": "employerToEmployee",
				"outputs": [
					{
						"internalType": "bool",
						"name": "",
						"type": "bool"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [],
				"name": "getAllEmployees",
				"outputs": [
					{
						"components": [
							{
								"internalType": "bool",
								"name": "isPartTime",
								"type": "bool"
							},
							{
								"internalType": "uint256",
								"name": "hourlyRate",
								"type": "uint256"
							},
							{
								"internalType": "uint256",
								"name": "workingHours",
								"type": "uint256"
							},
							{
								"internalType": "uint256",
								"name": "otRate",
								"type": "uint256"
							},
							{
								"internalType": "uint256",
								"name": "otHours",
								"type": "uint256"
							},
							{
								"internalType": "uint256",
								"name": "bonus",
								"type": "uint256"
							},
							{
								"internalType": "uint256",
								"name": "deduction",
								"type": "uint256"
							}
						],
						"internalType": "struct PayrollDApp.Employee[]",
						"name": "",
						"type": "tuple[]"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "_employer",
						"type": "address"
					}
				],
				"name": "getEmployerBalance",
				"outputs": [
					{
						"internalType": "uint256",
						"name": "",
						"type": "uint256"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [],
				"name": "owner",
				"outputs": [
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [
					{
						"internalType": "address",
						"name": "",
						"type": "address"
					},
					{
						"internalType": "uint256",
						"name": "",
						"type": "uint256"
					}
				],
				"name": "salaryTransactions",
				"outputs": [
					{
						"internalType": "uint256",
						"name": "txid",
						"type": "uint256"
					},
					{
						"internalType": "address",
						"name": "employee",
						"type": "address"
					},
					{
						"internalType": "uint256",
						"name": "amount",
						"type": "uint256"
					},
					{
						"internalType": "uint256",
						"name": "releaseTime",
						"type": "uint256"
					},
					{
						"internalType": "enum PayrollDApp.TimelockStatus",
						"name": "status",
						"type": "uint8"
					},
					{
						"internalType": "bool",
						"name": "processed",
						"type": "bool"
					},
					{
						"internalType": "string",
						"name": "description",
						"type": "string"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [],
				"name": "txCounter",
				"outputs": [
					{
						"internalType": "uint256",
						"name": "",
						"type": "uint256"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [],
				"name": "viewCancelledTimelocks",
				"outputs": [
					{
						"internalType": "uint256[]",
						"name": "",
						"type": "uint256[]"
					},
					{
						"internalType": "address[]",
						"name": "",
						"type": "address[]"
					},
					{
						"internalType": "uint256[]",
						"name": "",
						"type": "uint256[]"
					},
					{
						"internalType": "uint256[]",
						"name": "",
						"type": "uint256[]"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [],
				"name": "viewExecutedTimelocks",
				"outputs": [
					{
						"internalType": "uint256[]",
						"name": "",
						"type": "uint256[]"
					},
					{
						"internalType": "address[]",
						"name": "",
						"type": "address[]"
					},
					{
						"internalType": "uint256[]",
						"name": "",
						"type": "uint256[]"
					},
					{
						"internalType": "uint256[]",
						"name": "",
						"type": "uint256[]"
					}
				],
				"stateMutability": "view",
				"type": "function"
			},
			{
				"inputs": [],
				"name": "viewQueuedTimelocks",
				"outputs": [
					{
						"internalType": "uint256[]",
						"name": "",
						"type": "uint256[]"
					},
					{
						"internalType": "address[]",
						"name": "",
						"type": "address[]"
					},
					{
						"internalType": "uint256[]",
						"name": "",
						"type": "uint256[]"
					},
					{
						"internalType": "uint256[]",
						"name": "",
						"type": "uint256[]"
					}
				],
				"stateMutability": "view",
				"type": "function"
			}
		]; // Replace with the ABI of your contract



		window.addEventListener("load", async () => {
			if (window.ethereum) {
				web3 = new Web3(window.ethereum);
				try {
					await window.ethereum.request({ method: 'eth_requestAccounts' });
					const accounts = await web3.eth.getAccounts();

					const walletAddress = accounts[0];
					console.log("Connected wallet:", walletAddress);

					// Initialize the contract
					payrollDAppContract = new web3.eth.Contract(contractABI, contractAddress);
					console.log("Contract initialized:", payrollDAppContract);
				} catch (error) {
					console.error("Error connecting wallet:", error.message);
				}
			} else {
				alert("Please install MetaMask or another Ethereum wallet!");
			}
		});

	
		async function connectWallet() {

			if (window.ethereum) {

				 web3 = new Web3(window.ethereum);
				try {
					await window.ethereum.request({ method: 'eth_requestAccounts' });
					const accounts = await web3.eth.getAccounts();

					const walletAddress = accounts[0];
					console.log(walletAddress);

	
					payrollDAppContract = new web3.eth.Contract(contractABI, contractAddress);
				} catch (error) {
					alert("Error connecting wallet: " + error.message);
				}
			} else {
				alert("Please install MetaMask or another Ethereum wallet!");
			}
		}
	
		async function registerEmployer() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];
	
			try {
				await payrollDAppContract.methods.registerEmployer().send({ from: sender });
                alert("Sucessfully registered as an Employer");
 
			} catch (error) {
				alert("Error, you are already an Employer");
			}
		}
	
		async function fundEmployer() {

			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];
			const fundAmount = document.getElementById("fundAmount").value;
	
			if (!fundAmount || parseFloat(fundAmount) <= 0) {
				alert("Please enter a valid amount to fund.");
				return;
			}
	
			try {
				const amountInWei = web3.utils.toWei(fundAmount, "ether");
				await payrollDAppContract.methods.fundEmployer().send({
					from: sender,
					value: amountInWei
				});
				const balance = await payrollDAppContract.methods.getEmployerBalance(sender).call();
			    document.getElementById("employerBalance").innerText = web3.utils.fromWei(balance, "ether");
				alert("Sucessfully funded  Employer");
			} 
			catch (error) {
				alert("Error funding employer, check if you have enough ethereum in your wallet! ");
			}
		}
	
		async function withdrawFunds() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];
			const withdrawAmount = document.getElementById("withdrawAmount").value;
	
			if (!withdrawAmount || parseFloat(withdrawAmount) <= 0) {
				alert("Please enter a valid amount to withdraw.");
				return;
			}
	
			try {
				const amountInWei = web3.utils.toWei(withdrawAmount, "ether");
				await payrollDAppContract.methods.withdrawFunds(amountInWei).send({ from: sender });
				alert("Sucessfully withdrawn funds to Employer");
			} catch (error) {
				alert("Error withdrawing funds, inssuficient funds to withdraw " );
			}
		}
	
		async function addEmployee() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];
		
			const employeeAddress = document.getElementById("employeeAddress").value;
			const isPartTime = document.getElementById("isPartTime").value === "true";
			const hourlyRate = web3.utils.toWei(document.getElementById("hourlyRate").value, "ether");
			const workingHours = document.getElementById("workingHours").value;
			const otRate = web3.utils.toWei(document.getElementById("otRate").value, "ether");
			const otHours = document.getElementById("otHours").value;
			const bonus = web3.utils.toWei(document.getElementById("bonus").value, "ether");
			const deduction = web3.utils.toWei(document.getElementById("deduction").value, "ether");
		
			// Validate input
			if (!employeeAddress || !hourlyRate || !workingHours || !otRate || !otHours || !bonus || !deduction) {
				alert("Please fill in all fields to add an employee.");
				return;
			}
		
			try {
				// Interact with the smart contract
				await payrollDAppContract.methods
					.addEmployee(
						employeeAddress,
						isPartTime,
						hourlyRate,
						workingHours,
						otRate,
						otHours,
						bonus,
						deduction
					)
					.send({ from: sender });
		
				
				// Clear input fields
				document.getElementById("employeeForm").reset();
		
				alert("Employee added successfully!");
			} catch (error) {
				alert("Error adding employee, this employee had already been registered! " );
			}
		}
		
		function updateEmployeeTable() {
			const employees = JSON.parse(localStorage.getItem("employees")) || [];
			const tableBody = document.getElementById("employeeTableBody");
		
			// Clear the table body
			tableBody.innerHTML = "";
		
			// Populate the table with employee data
			employees.forEach((employee, index) => {
				const row = `
					<tr>
						<td>${index + 1}</td>
						<td>${employee.employeeAddress}</td>
						<td>${employee.isPartTime ? "Yes" : "No"}</td>
						<td>${employee.hourlyRate} ETH</td>
						<td>${employee.workingHours}</td>
						<td>${employee.otRate} ETH</td>
						<td>${employee.otHours}</td>
						<td>${employee.bonus} ETH</td>
						<td>${employee.deduction} ETH</td>
						
					</tr>
				`;
				tableBody.insertAdjacentHTML("beforeend", row);
			});
		}
		
		
	
		async function modifyEmployee() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];
	
			const employeeAddress = document.getElementById("modifyEmployeeAddress").value;
			const isPartTime = document.getElementById("modifyIsPartTime").value === "true";
			const hourlyRate = web3.utils.toWei(document.getElementById("modifyHourlyRate").value, "ether");
			const workingHours = document.getElementById("modifyWorkingHours").value;
			const otRate = web3.utils.toWei(document.getElementById("modifyOtRate").value, "ether");
			const otHours = document.getElementById("modifyOtHours").value;
			const bonus = web3.utils.toWei(document.getElementById("modifyBonus").value, "ether");
			const deduction = web3.utils.toWei(document.getElementById("modifyDeduction").value, "ether");
	
			if (!employeeAddress || !hourlyRate || !workingHours || !otRate || !otHours || !bonus || !deduction) {
				alert("Please fill in all fields to modify the employee.");
				return;
			}
	
			try {
				await payrollDAppContract.methods.modifyEmployeeDetails(
					employeeAddress,
					isPartTime,
					hourlyRate,
					workingHours,
					otRate,
					otHours,
					bonus,
					deduction
				).send({ from: sender });
			} catch (error) {
				alert("Error modifying employee, this employee does not exist in database! " );
			}

			updateEmployeeTable();
		}
	
		async function deleteEmployee() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];
	
			const employeeAddress = document.getElementById("deleteEmployeeAddress").value;
	
			if (!employeeAddress) {
				alert("Please enter an employee address to delete.");
				return;
			}
	
			try {
				await payrollDAppContract.methods.deleteEmployee(employeeAddress).send({ from: sender });
			} catch (error) {
				alert("Error deleting employee, employee does not exist in database!");
			}
		}

		
	
		async function payAllSalaries() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];
			
			try {
				await payrollDAppContract.methods.payAllSalaries().send({ from: sender });
			} catch (error) {
				alert("Error paying all salaries, inssuficient funds! ") ;
			}
		}
		// Function to fetch and display employee details
		async function fetchAndDisplayEmployees() {
			try {
				const accounts = await web3.eth.getAccounts();
				const sender = accounts[0];
				// Fetch all employees' details from the contract
				const employees = await payrollDAppContract.methods.getAllEmployees().call({ from: sender });
		
				// Get the table element
				const table = document.getElementById("employeeTable");
		
				// Ensure the table exists
				if (!table) {
					console.error("Table with id 'employeeTable' not found.");
					return;
				}
		
				// Update the table headers dynamically
				table.innerHTML = `
					<thead>
						<tr>
							<th>#</th>
							<th>Type</th>
							<th>Hourly Rate (ETH)</th>
							<th>Working Hours</th>
							<th>OT Rate (ETH)</th>
							<th>OT Hours</th>
							<th>Bonus (ETH)</th>
							<th>Deduction (ETH)</th>
						</tr>
					</thead>
					<tbody id="employeeTableBody">
						<!-- Dynamic rows will be added here -->
					</tbody>
				`;
		
				const tableBody = document.getElementById("employeeTableBody");
				tableBody.innerHTML = ""; // Clear existing rows
		
				// Populate the table rows with employee details
				employees.forEach((employee, index) => {
					const row = document.createElement("tr");
		
					row.innerHTML = `
						<td>${index + 1}</td>
						<td>${employee.isPartTime ? "Part-Time" : "Full-Time"}</td>
						<td>${web3.utils.fromWei(employee.hourlyRate, "ether")} ETH</td>
						<td>${employee.workingHours}</td>
						<td>${web3.utils.fromWei(employee.otRate, "ether")} ETH</td>
						<td>${employee.otHours}</td>
						<td>${web3.utils.fromWei(employee.bonus, "ether")} ETH</td>
						<td>${web3.utils.fromWei(employee.deduction, "ether")} ETH</td>
					`;
		
					tableBody.appendChild(row); // Add the row to the table body
				});
		
				// If no employees are returned, show a message
				if (employees.length === 0) {
					const emptyRow = document.createElement("tr");
					emptyRow.innerHTML = `
						<td colspan="8" style="text-align: center;">No employees found.</td>
					`;
					tableBody.appendChild(emptyRow);
				}
			} catch (error) {
				console.error("Error fetching employee details:", error);
				alert("Failed to retrieve employee details. Please try again.or you are not an employee");
		    }
		}

		
		async function setSalaryTimelock() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];
		
			const employeeAddress = document.getElementById("timelockEmployeeAddress").value.trim(); // Trim to avoid leading/trailing spaces
			const releaseTimeInput = document.getElementById("timelockTime").value;
		
			if (!employeeAddress) {
				alert("Please enter a valid employee address.");
				return;
			}
		
			const releaseTime = new Date(releaseTimeInput).getTime() / 1000;
		
			if (!releaseTimeInput || isNaN(releaseTime)) {
				alert("Please enter a valid release time.");
				return;
			}
		
			try {
				await payrollDAppContract.methods
					.setSalaryTimelock(employeeAddress, releaseTime)
					.send({ from: sender });
				alert("Timelock successfully set!");
			} catch (error) {
				console.error("Error setting timelock:", error);
				alert("Failed to set timelock. Check the console for details.");
		    }
		}
//timelock check
async function fetchQueuedTimelocks() {
    try {
        const accounts = await web3.eth.getAccounts();
        const result = await payrollDAppContract.methods.viewQueuedTimelocks().call({ from: accounts[0] });
        displayQueuedTimelocks(result);
    } catch (error) {
        console.error("Error fetching queued timelocks:", error);
        alert("Failed to fetch queued timelocks.");
    }
}

function displayQueuedTimelocks({ 0: txids, 1: employees, 2: amounts, 3: releaseTimes }) {
    const tableBody = document.querySelector("#queuedTimelocks tbody");
    tableBody.innerHTML = ""; 
    for (let i = 0; i < txids.length; i++) {
        const row = document.createElement("tr");
        const amountInEther = web3.utils.fromWei(amounts[i].toString(), "ether");
        const releaseTime = new Date(Number(releaseTimes[i]) * 1000).toLocaleString();
        row.innerHTML = `
            <td>${txids[i]}</td>
            <td>${employees[i]}</td>
            <td>${amountInEther} ETH</td>
            <td>${releaseTime}</td>
        `;
        tableBody.appendChild(row);
    }
}

async function fetchExecutedTimelocks() {
    try {
        const accounts = await web3.eth.getAccounts();
        const result = await payrollDAppContract.methods.viewExecutedTimelocks().call({ from: accounts[0] });

        // Only display executed timelocks with Generate Payslip buttons
        displayExecutedTimelocks(result);
    } catch (error) {
        console.error("Error fetching executed timelocks:", error);
        alert("Failed to fetch executed timelocks.");
    }
}

function displayExecutedTimelocks({ 0: txids, 1: employees, 2: amounts, 3: releaseTimes }) {
	const tableBody = document.querySelector("#executedTimelocks tbody");
	tableBody.innerHTML = ""; 
	for (let i = 0; i < txids.length; i++) {
		const row = document.createElement("tr");
		const amountInEther = web3.utils.fromWei(amounts[i].toString(), "ether");
		const releaseTime = new Date(Number(releaseTimes[i]) * 1000).toLocaleString();
		row.innerHTML = `
			<td>${txids[i]}</td>
			<td>${employees[i]}</td>
			<td>${amountInEther} ETH</td>
			<td>${releaseTime}</td>
			<td><button class="generate-payslip-btn" onclick="generatePayslip('${txids[i]}', '${employees[i]}', '${amountInEther}', '${releaseTime}')">Generate Payslip</button></td>
		`;
		tableBody.appendChild(row);
	}
}

async function fetchCancelledTimelocks() {
    try {
        const accounts = await web3.eth.getAccounts();
        const result = await payrollDAppContract.methods.viewCancelledTimelocks().call({ from: accounts[0] });
        displayCancelledTimelocks(result);
    } catch (error) {
        console.error("Error fetching cancelled timelocks:", error);
        alert("Failed to fetch cancelled timelocks.");
    }
}

function displayCancelledTimelocks({ 0: txids, 1: employees, 2: amounts, 3: releaseTimes }) {
    const tableBody = document.querySelector("#cancelledTimelocks tbody");
    tableBody.innerHTML = ""; 
    for (let i = 0; i < txids.length; i++) {
        const row = document.createElement("tr");
        const amountInEther = web3.utils.fromWei(amounts[i].toString(), "ether");
        const releaseTime = new Date(Number(releaseTimes[i]) * 1000).toLocaleString();
        row.innerHTML = `
            <td>${txids[i]}</td>
            <td>${employees[i]}</td>
            <td>${amountInEther} ETH</td>
            <td>${releaseTime}</td>
        `;
        tableBody.appendChild(row);
    }
}

const queuedTab = document.getElementById("queuedTab");
if (queuedTab) {
    queuedTab.addEventListener("click", (event) => {
        event.preventDefault();
        fetchQueuedTimelocks();
    });
}

const executedTab = document.getElementById("executedTab");
if (executedTab) {
    executedTab.addEventListener("click", (event) => {
        event.preventDefault();
        fetchExecutedTimelocks();
    });
}

const cancelledTab = document.getElementById("cancelledTab");
if (cancelledTab) {
    cancelledTab.addEventListener("click", (event) => {
        event.preventDefault();
        fetchCancelledTimelocks();
    });
}
//timelock check

			async function setSalaryTimelockForAll() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];

			const releaseTime = new Date(document.getElementById("timelockTimeAll").value).getTime() / 1000;

			if (!releaseTime) {
				alert("Please enter a valid release time for all employees.");
				return;
			}

			await payrollDAppContract.methods.setSalaryTimelockForAll(releaseTime).send({ from: sender });
		}

				async function checkSalaryTimelocks() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];

			try {
				const result = await payrollDAppContract.methods.checkSalaryTimelocks().call({ from: sender });

				if (!result || !Array.isArray(result[0]) || !Array.isArray(result[1])) {
					throw new Error("Unexpected response format from checkSalaryTimelocks.");
				}

				const employees = result[0]; // Array of employee addresses
				const releaseTimes = result[1]; // Array of release times

				if (employees.length === 0) {
					const salaryTimelocksElement = document.getElementById("salaryTimelocks");
					if (!salaryTimelocksElement) throw new Error("Cannot find the element with id 'salaryTimelocks'.");
					salaryTimelocksElement.value = "No salary timelocks found.";
					return;
				}

				let details = "Salary Timelocks:\n";
				for (let i = 0; i < employees.length; i++) {
					const releaseDate = new Date(parseInt(releaseTimes[i].toString()) * 1000).toLocaleString();
					details += `Employee: ${employees[i]} | Release Time: ${releaseDate}\n`;
				}

				const salaryTimelocksElement = document.getElementById("salaryTimelocks");
				if (!salaryTimelocksElement) throw new Error("Cannot find the element with id 'salaryTimelocks'.");
				salaryTimelocksElement.value = details;

			} catch (error) {
				console.error("Error checking salary timelocks:", error);
			}
		}


		async function payIndividualSalary() {
			const accounts = await web3.eth.getAccounts();
			const sender = accounts[0];
	
			const txid = document.getElementById("employeeAddressforPaying").value;
	
			if (!txid) {
				alert("Please enter an transaction ID to pay.");
				return;
			}
	
			try {
				await payrollDAppContract.methods.payIndividualSalary(txid).send({ from: sender });
			} catch (error) {
				alert("Error paying for employee, inssuficient funds! " );
			}
}

async function getEmployeeList() {
    try {
        const accounts = await web3.eth.getAccounts();
        const sender = accounts[0];

        // Fetch the employee list from the smart contract
        const employeeList = await payrollDAppContract.methods.checkEmployeeList(sender).call();

        // Get the table element
        const table = document.getElementById("employeeTable");
        
        // Update the table header
        table.innerHTML = `
            <thead>
                <tr>
                    <th>#</th>
                    <th>Employee Address</th>
                </tr>
            </thead>
            <tbody id="employeeTableBody"></tbody>
        `;

        // Get the updated table body element
        const tableBody = document.getElementById("employeeTableBody");

        // Populate the table with employee addresses
        employeeList.forEach((employeeAddress, index) => {
            const row = document.createElement("tr");

            row.innerHTML = `
                <td>${index + 1}</td>
                <td>${employeeAddress}</td>
            `;

            tableBody.appendChild(row);
        });
    } catch (error) {
        console.error("Error fetching employee list:", error);
        alert("Failed to retrieve employee list.");
    }
}
		async function calculateSalary() {
    const accounts = await web3.eth.getAccounts();
    const sender = accounts[0];

    const employeeAddress = document.getElementById("calculateEmployeeAddress").value;

    if (!employeeAddress) {
        alert("Please enter an employee address to calculate salary.");
        return;
    }

    const salary = await payrollDAppContract.methods.calculateSalary(sender, employeeAddress).call();

    document.getElementById("calculatedSalary").innerText = "Calculated Salary: " + web3.utils.fromWei(salary, "ether") + " ETH";
}

		async function getEmployerBalance() {
    const accounts = await web3.eth.getAccounts();
    const sender = accounts[0];

    const balance = await payrollDAppContract.methods.getEmployerBalance(sender).call();

    document.getElementById("employerBalance").innerText =  web3.utils.fromWei(balance, "ether");
	document.getElementById("employerBalance2").innerText =  web3.utils.fromWei(balance, "ether");
}

		async function monitorSalaryTimelocks() {
    const accounts = await web3.eth.getAccounts();
    const sender = accounts[0];

    setInterval(async () => {
        try {
            const result = await payrollDAppContract.methods.checkSalaryTimelocks().call({ from: sender });

            const employees = result[0]; // Array of employee addresses
            const releaseTimes = result[1]; // Array of release times
            const currentTime = Math.floor(Date.now() / 1000);

            for (let i = 0; i < employees.length; i++) {
                if (currentTime >= releaseTimes[i]) {
                    await payrollDAppContract.methods.payAllSalaries().send({ from: sender });
                    break; // Call `payAllSalaries` only once per interval.
                }
            }
        } catch (error) {
            console.error("Error during salary timelock monitoring:", error);
        }
    }, 30000); // Check every 30 seconds.
}

async function modifyTimelock() {
    const accounts = await web3.eth.getAccounts();
    const sender = accounts[0];

    const txid = document.getElementById("modifyTimelockId").value;
    const amount = document.getElementById("modifyAmount").value;
    const releaseTimeInput = document.getElementById("modifyReleaseTime").value;

    if (!txid || !amount || !releaseTimeInput) {
        alert("Please fill in all fields.");
        return;
    }

    const amountInWei = web3.utils.toWei(amount, "ether");
    const releaseTime = new Date(releaseTimeInput).getTime() / 1000;

    try {
        await payrollDAppContract.methods
            .modifyTimelock(txid, amountInWei, releaseTime)
            .send({ from: sender });
        alert("Timelock modified successfully!");
    } catch (error) {
        alert("Error modifying timelockm, ensure you input the correct transaction ID! " );
    }
}

async function deleteTimeLock() {
	const accounts = await web3.eth.getAccounts();
	const sender = accounts[0];

	const txid1 = document.getElementById("deleteTimelock").value;

	if (!txid1) {
		alert("Please enter a transaction ID to delete. ");
		return;
	}

	try {
		await payrollDAppContract.methods.deleteTimelock(txid1).send({ from: sender });
	} catch (error) {
		alert("Error deleting timelock, ensure you input the correct transaction ID! " );
	}
}



		// Wait for the DOM to load before adding event listeners
document.addEventListener("DOMContentLoaded", () => {
    const connectButton = document.getElementById("connectButton");
    if (connectButton) {
		console.log("1");
        connectButton.addEventListener("click", async () => {
			console.log("2");
            await connectWallet();
			console.log("3");

            monitorSalaryTimelocks(); // Start monitoring after connecting the wallet
			console.log("4");

        });
    }

	async function deleteEmployee() {
		const accounts = await web3.eth.getAccounts();
		const sender = accounts[0];

		const employeeAddress = document.getElementById("deleteEmployeeAddress").value;

		if (!employeeAddress) {
			alert("Please enter an employee address to delete.");
			return;
		}

		try {
			await payrollDAppContract.methods.deleteEmployee(employeeAddress).send({ from: sender });
		} catch (error) {
			alert("Error deleting employee, ensure you input the correct employee wallet address! " );
		}
	}

	
	
	async function fetchQueuedTimelocks() {
		const accounts = await web3.eth.getAccounts();
		const userAddress = accounts[0];
	
		try {
			// Call the `viewQueuedTimelocks` function
			const result = await payrollDAppContract.methods.viewQueuedTimelocks().call({ from: userAddress });
	console.log("hi");
			// Populate the table with the fetched data
			displayQueuedTimelocks(result);
		} catch (error) {
			console.error("Error fetching queued timelocks:", error);
		}
	}
	
	function displayQueuedTimelocks({ 0: txids, 1: employees, 2: amounts, 3: releaseTimes }) {
		const tableBody = document.querySelector("#queuedTimelocks tbody");
		tableBody.innerHTML = ""; // Clear previous content
	
		txids.forEach((txid, index) => {
			const amountInEther = web3.utils.fromWei(amounts[index].toString(), "ether"); // Convert BigInt to Strin	g
			const releaseTime = new Date(Number(releaseTimes[index]) * 1000).toLocaleString(); // Convert BigInt to Number
	
			const row = `
				<tr>
					<td>${txid}</td>
					<td>${employees[index]}</td>
					<td>${amountInEther} ETH</td>
					<td>${releaseTime}</td>
				</tr>
			`;
			tableBody.insertAdjacentHTML("beforeend", row);
		});
	
		// Ensure the container stays visible
		document.getElementById("queuedTimelocks").classList.add("active");
	}

	

    const registerEmployerButton = document.getElementById("registerEmployerButton");
    if (registerEmployerButton) {
        registerEmployerButton.addEventListener("click", registerEmployer);
    }

    const fundEmployerButton = document.getElementById("fundEmployerButton");
    if (fundEmployerButton) {
        fundEmployerButton.addEventListener("click", fundEmployer);
    }

    const withdrawFundsButton = document.getElementById("withdrawFundsButton");
    if (withdrawFundsButton) {
        withdrawFundsButton.addEventListener("click", withdrawFunds);
    }

    const addEmployeeButton = document.getElementById("addEmployeeButton");
    if (addEmployeeButton) {
        addEmployeeButton.addEventListener("click", addEmployee);
    }

    const modifyEmployeeButton = document.getElementById("modifyEmployeeButton");
    if (modifyEmployeeButton) {
        modifyEmployeeButton.addEventListener("click", modifyEmployee);
    }

    const deleteEmployeeButton = document.getElementById("deleteEmployeeButton");
    if (deleteEmployeeButton) {
        deleteEmployeeButton.addEventListener("click", deleteEmployee);
    }

    const payAllSalariesButton = document.getElementById("payAllSalariesButton");
    if (payAllSalariesButton) {
        payAllSalariesButton.addEventListener("click", payAllSalaries);
    }

	const payIndividualSalaryButton = document.getElementById("payIndividualSalaryButton");
    if (payIndividualSalaryButton) {
        payIndividualSalaryButton.addEventListener("click", payIndividualSalary);
    }

	const modifyTimelockButton = document.getElementById("modifyTimelockButton");
	if (modifyTimelockButton) {
		modifyTimelockButton.addEventListener("click", modifyTimelock);
	}
	
	const deleteTimelock = document.getElementById("timelock");
    if (deleteTimelock) {
        deleteTimelock.addEventListener("click", deleteTimeLock);
    }
	

    const getEmployeeListButton = document.getElementById("getEmployeeListButton");
    if (getEmployeeListButton) {
        getEmployeeListButton.addEventListener("click", getEmployeeList);
    }

    const calculateSalaryButton = document.getElementById("calculateSalaryButton");
    if (calculateSalaryButton) {
        calculateSalaryButton.addEventListener("click", calculateSalary);
    }

    const getEmployerBalanceButton = document.getElementById("getEmployerBalanceButton");
    if (getEmployerBalanceButton) {
        getEmployerBalanceButton.addEventListener("click", getEmployerBalance);
    }

	//duplicated getEmployerBalance for withdrawfund page.
	const getEmployerBalanceButton2 = document.getElementById("getEmployerBalanceButton2");
    if (getEmployerBalanceButton2) {
        getEmployerBalanceButton2.addEventListener("click", getEmployerBalance);
    }

    const setTimelockButton = document.getElementById("setTimelockButton");
    if (setTimelockButton) {
        setTimelockButton.addEventListener("click", setSalaryTimelock);
    }

    const setTimelockAllButton = document.getElementById("setTimelockAllButton");
    if (setTimelockAllButton) {
        setTimelockAllButton.addEventListener("click", setSalaryTimelockForAll);
    }

    const checkSalaryTimelocksButton = document.getElementById("checkSalaryTimelocksButton");
    if (checkSalaryTimelocksButton) {
        checkSalaryTimelocksButton.addEventListener("click", checkSalaryTimelocks);
    }

	const displayButton = document.getElementById("displayStaffButton");
    // Ensure the button exists before attaching the listener
    if (displayButton) {
       // Add click event listener to fetch and display employees
    	displayButton.addEventListener("click", fetchAndDisplayEmployees);
    }

	// Call this function on page load to populate the table with existing data
	document.addEventListener("DOMContentLoaded", updateEmployeeTable);
		
	

});

	